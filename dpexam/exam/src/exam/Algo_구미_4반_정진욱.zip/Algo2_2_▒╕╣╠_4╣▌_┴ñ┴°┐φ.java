package exam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Algo2_2_구미_4반_정진욱 {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	static int V,P,L;//V 마을 수, P 경찰서 수, L 원의 길이
	static int [] map;//마을의 위치 좌표
	static int min,res;
	static boolean[] v;
	public static void main(String[] args) throws NumberFormatException, IOException {
		int t = Integer.parseInt(br.readLine());//몇번 테스트 할지
		for(int tc=1;tc<=t;tc++) {//반복
			st=new StringTokenizer(br.readLine());
			V=Integer.parseInt(st.nextToken());//마을 수 입력
			P=Integer.parseInt(st.nextToken());//경찰서 수 입력
			L=Integer.parseInt(st.nextToken());//원의 길이
			map = new int[V];//위치좌표 선언
			st=new StringTokenizer(br.readLine());
			for(int i=0;i<V;i++) {//마을 좌표 입력받기
				map[i]=Integer.parseInt(st.nextToken());
			}
			v=new boolean[V];
			res=Integer.MAX_VALUE;//최솟값을 구하기 위해 최댓값 선언
			dfs(0,0);//조합 
			System.out.println("#"+tc+" "+res);//결과 출력
			
		}

	}
	static void dfs(int idx,int cnt) {//조합
		if(cnt==P) {//경찰서의 개수만큼 골랐으면
			min=0;//거리의 합을 저장할 변수
			ArrayList<Integer> list = new ArrayList<>();
			for(int i=0;i<V;i++) {//모든 마을 탐색
				if(v[i]) {//경찰서를 지을 i번째 마을을 선택 했다면
					list.add(map[i]);//선택한 마을 리스트에 저장
				}
			}
			for(int i=0;i<V;i++) {//모든 마을과 비교
				int m = Integer.MAX_VALUE;//최소값을 구하기 위해 최댓값 선언
				for(int j=0;j<list.size();j++) {//고른 마을과 비교
					m=Math.min(m,Math.min(L-Math.abs(map[i]-list.get(j)) ,Math.abs(map[i]-list.get(j))));//고른 마을과 다른마을의 거리와 반대로 갈 경우의 거리중 작은 거리 선택
				}
				min+=m;//한마을에서 가장 가까운 경찰서의 거리 저장
			}
			res=Math.min(min, res);//이번에 구한 조합에서 나온 거리의 합과 이전에 구한 거리의 합을 비교해 더 작은 값을 res에 저장
			return;
		}
		if(idx==V) return;//마을을 끝까지 탐색했으면 리턴
		
		v[idx]=true;//고르기
		dfs(idx+1,cnt+1);//다시 고르기
		v[idx]=false;//다른 조합을 찾기 위해 고른 것 취소
		dfs(idx+1,cnt);//다시 고르기
	}

}
